<?php
?>
@extends('layouts.app')


@section('content')



<table class="table">
    <thead>
        <tr>
            <th scope="col">User ID</th>
            <th scope="col">Name</th>
            <th scope="col">Username</th>
            <th scope="col">Password</th>
            <th scope="col">Email</th>
            <th scope="col">Role</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Patrick Ulmer</td>
            <td>PattyUlms</td>
            <td>Pass4Jobs</td>
            <td>laxulmer@gmail.com</td>
            <td>Admin</td>
           
            <td><button type="button" class="btn btn-danger">Friend Request</button></td>
 
 
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>Nate Kelly</td>
            <td>DEMREX</td>
            <td>passwords</td>
            <td>NateK@gmail.com</td>
            <td>Admin</td>
            <td><button type="button" class="btn btn-danger">Friend Request</button></td>

        </tr>
        <tr>
            <th scope="row">3</th>
            <td>Corrina Franco</td>
            <td>Cfranc</td>
            <td>passwords</td>
            <td>Cfranc@gmail.com</td>
            <td>User</td>
            <td><button type="button" class="btn btn-danger">Friend Request</button></td>

        </tr>
         <tr>
            <th scope="row">3</th>
            <td>Matt Ulmer</td>
            <td>MUlmer</td>
            <td>passwords</td>
            <td>Matt@gmail.com</td>
            <td>User</td>
            <td><button type="button" class="btn btn-danger">Edit Profile</button></td>
            <td><button type="button" class="btn btn-warning">Delete User</button></td>
            <td><button type="button" class="btn btn-warning">Suspend User</button></td>
        </tr>
    </tbody>
</table>



@endsection
