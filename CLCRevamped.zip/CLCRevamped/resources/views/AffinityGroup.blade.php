<?php
/*
 * CST-256 CLC
 * Alec, Nate and Patrick
 * This is a statement of our own work
 * 
 */
?>
@extends('layouts.app')


@section('content')


<h1>Hello! Here you can join groups of similar interests!</h1>
<table class="table">
    <thead>
        <tr>
        <th scope="col">Group ID</th>
            <th scope="col">Group Title</th>

            <th scope="col">Description</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Java for Web Developers</td>
            
            <td>Group of developers with like interests to develop websites using js</td>
            <td><button type="button" class="btn btn-success">Join Group</button></td>
            <td><button type="button" class="btn btn-danger">Delete Group</button></td>
            <td><button type="button" class="btn btn-warning">Edit Group</button></td>
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>PHP using laravel</td>
            
            <td>CST 256 PHP for Professor Hughes</td>
            <td><button type="button" class="btn btn-success">Join Group</button></td>
            <td><button type="button" class="btn btn-danger">Delete Group</button></td>
            <td><button type="button" class="btn btn-warning">Edit Group</button></td>
        </tr>
    </tbody>
</table>

@endsection
