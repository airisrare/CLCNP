<?php
namespace App\Services\Business;

use App\Services\User\GroupDAO;

class EntityBusiness
{

    private $VerifyCredit;

    // find by ID 
    public function Create($Group)
    {
        $this->VerifyCredit = new GroupDAO();

        return $this->VerifyCredit->CreateGroup($Group);
    }

    // Delete User from group
    public function DeleteUser($credits)
    {
        $this->VerifyCredit = new GroupDAO();

        return $this->VerifyCredit->DeleteUsername($credits);
    }

    // User is apart of the group, cannot join again
    public function Verify($User)
    {
        $this->VerifyCredit = new GroupDAO();

        return $this->VerifyCredit->UserExists($User);
    }

    // show everyone in the group
    public function ShowAll($users)
    {
        $this->VerifyCredit = new GroupDAO();

        return $this->VerifyCredit->AllUsers();
    }
}
?>
