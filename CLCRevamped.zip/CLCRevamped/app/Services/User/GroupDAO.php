<?php
/*
 * Nate K
 * Patrick Ulmer
 * Milestone 4 Groups
 */
namespace App\Services\User;

// use App\Models\User;
// use App\Services\Generic\DBConnector;
use Carbon\Exceptions\Exception;
use Illuminate\Queue\Connectors\DatabaseConnector;
use App\Services\User;

class GroupDAO
{

    // show everyoen whos in the group
    public static function AllUsers()
    {
        // Connection
        $conn = DatabaseConnector::GetConnection();

        if ($conn->connect_error) {
            echo ("Connection failed: " . $conn->connect_error);
            return None;
        }
        // sql
        try {
            $query = "SELECT user_id, username, FROM EntityGroup";
            $result = $conn->query($query);

            // what we're passing
            $users = array();

            while ($row = $result->fetch_assoc()) {
                $user_id = $row['user_id'];
                $username = $row['username'];

                $users[] = new User($user_id, $username);
            }
            // always free the result
            mysqli_free_result($result);

            // close the connection
            DatabaseConnector::CloseConnection($conn);

            // return
            return $users;
        } catch (Exception $e) {
            echo $e->getMessage();
            return ex;
        }
    }

    // remove from the group
    public static function DeleteUsername(string $userName)
    {
        $conn = DatabaseConnector::GetConnection();

        if ($conn->connect_error) {
            echo ("Connection failed: " . $conn->connect_error);
            return None;
        }
        // SQL TO REMOVE
        try {
            $query = "DELETE user_id, userName FROM EntityGroup WHERE userName=?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $userName);

            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($user_id, $userName);
            $stmt->fetch();

            $user = new User($user_id, $userName);

            // close the connection
            DatabaseConnector::CloseConnection($conn);

            // return
            return $users;
        } catch (Exception $e) {
            echo $e->getMessage();
            return ex;
        }
    }

    // did this person join already?
    public static function UserExists(string $username)
    {
        // get connection
        $conn = DatabaseConnector::GetConnection();

        if ($conn->connect_error) {
            echo ("Connection failed: " . $conn->connect_error);
            return False;
        }
        // SQL
        try {
            $query = "SELECT COUNT(1) FROM EntityGroup WHERE username=?";
            // bind and execute
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $username);

            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($user_exist);
            $stmt->fetch();

            // always free the result
            mysqli_free_result($stmt);

            // close the connection
            DatabaseConnector::CloseConnection($conn);

            // return
            return $users_exist;
        } catch (Exception $e) {
            echo $e->getMessage();
            return ex;
        }
    }

    // function to create the group in the database
    public static function CreateGroup(string $GroupName)
    {
        // get DB cxonnection
        $conn = DatabaseConnector::GetConnection();

        if ($conn->connect_error) {
            echo ("Connection failed: " . $conn->connect_error);
            return False;
        }
        // run SQL
        try {
            $query = "INSERT INTO EntityGroup (GroupName) VALUES (?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $GroupName);

            $success = $stmt->execute();

            // always free the result

            mysqli_free_result($stmt);

            // close the connection
            DatabaseConnector::CloseConnection($conn);

            // return
            return $success;
        } catch (Exception $e) {
            echo $e->getMessage();
            return ex;
        }
    }
}