<?php
/*
 * CST-256 CLC
 * Alec, Nate and Patrick
 * This is a statement of our own work
 * 
 */
?>



<?php $__env->startSection('content'); ?>


<h1>Hello! This the Job posting page!</h1>
<table class="table">
    <thead>
        <tr>
        <th scope="col">Listing ID</th>
            <th scope="col">Company Name</th>
            <th scope="col">Title</th>
            <th scope="col">Salary</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Apple</td>
            <td>Cellular Design Specialist</td>
            <td>$ 100,000</td>
            <td><button type="button" class="btn btn-danger">Edit Job Posting</button></td>
            <td><button type="button" class="btn btn-warning">See whos applied</button></td>
        </tr>
         <tr>
            <th scope="row">2</th>
            <td>Intel</td>
            <td>Web Developer</td>
            <td>$ 105,000</td>
            <td><button type="button" class="btn btn-danger">Edit Job Posting</button></td>
            <td><button type="button" class="btn btn-warning">See whos applied</button></td>
        </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\CLCRevamped\resources\views/showAllJobListingsUser.blade.php ENDPATH**/ ?>